PHASE: INSTALL -> VALIDATE -> HARDEN
STEP: Install frontend ceiling workbook and implement frontend source-truth controls

Repo:
Strategic-Minds/INTELLIGENCE-CUBE

Branch:
codex/install-frontend-ceiling-workbook

Do not push to main.
Do not deploy production.
Do not expose secrets.
Do not mark production-ready.
Do not overwrite existing workbook source truth.

Install this workbook at:
01_Builder_Docs/frontend-ceiling/AUTO_BUILDER_FRONTEND_CEILING_WORKBOOK.xlsx

Use this workbook as the frontend command ledger together with:
01_Builder_Docs/highest-repo-ceiling-all-in-one/AUTO_BUILDER_HIGHEST_REPO_CEILING_ALL_IN_ONE_WORKBOOK.xlsx

Mission:
1. Add the workbook package under 01_Builder_Docs/frontend-ceiling/.
2. Add a README explaining that this workbook governs frontend planning, UI implementation, component rules, responsive behavior, accessibility, performance, forms, frontend data contracts, Vercel/Next.js runtime planning, Supabase frontend contracts, validation, receipts, and release gates.
3. Update WORKBOOK_OS_MANIFEST.json to register this workbook as FRONTEND_CEILING_WORKBOOK with source_of_truth_rank support/frontend_primary.
4. Add or update CODEX_HANDOFF.md or CODEX_HANDOFF_RULES.md with a frontend-ceiling section.
5. Add a validator script: scripts/workbook_validation/validate_frontend_ceiling_workbook.py.
6. Add a receipt: 03_Bridge_Receipts/frontend/RECEIPT_FRONTEND_CEILING_WORKBOOK_INSTALL.md.
7. If app/components/lib/tests exist, inspect them and update 18_FRONTEND_GAP_LEDGER with real current status.
8. Do not create production Vercel deployment.
9. Do not change production env vars.
10. Do not add live connector actions.

Required validation:
python scripts/workbook_validation/validate_frontend_ceiling_workbook.py 01_Builder_Docs/frontend-ceiling/AUTO_BUILDER_FRONTEND_CEILING_WORKBOOK.xlsx
python scripts/workbook_validation/validate_manifest.py if present
python scripts/workbook_validation/validate_public_repo_boundaries.py if present
npm ci if package-lock.json exists
npm install if package.json exists and no lockfile exists
npm run build if available
npm run test if available
npm run test:smoke if available
npx playwright test if configured

Final output required:
PHASE:
STEP:
BRANCH:
FILES INSTALLED:
FILES CHANGED:
WORKBOOK REGISTERED:
FRONTEND GAPS FOUND:
FRONTEND GAPS CLOSED:
VALIDATION COMMANDS RUN:
VALIDATION RESULTS:
RECEIPTS CREATED:
MERGE READINESS:
PRODUCTION READINESS:
BLOCKERS:
NEXT ACTIONS:
