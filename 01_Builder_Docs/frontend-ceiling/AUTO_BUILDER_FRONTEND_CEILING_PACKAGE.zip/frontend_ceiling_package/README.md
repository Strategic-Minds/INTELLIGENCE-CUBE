# AUTO BUILDER Frontend Ceiling Workbook

This package contains the frontend ceiling workbook for Strategic-Minds/INTELLIGENCE-CUBE.

## Purpose

The workbook forces GPT, Codex, Base44, and human operators to use one frontend command ledger before planning, building, or auditing UI/frontend work.

## Install path

`01_Builder_Docs/frontend-ceiling/AUTO_BUILDER_FRONTEND_CEILING_WORKBOOK.xlsx`

## Use with

- `01_Builder_Docs/highest-repo-ceiling-all-in-one/AUTO_BUILDER_HIGHEST_REPO_CEILING_ALL_IN_ONE_WORKBOOK.xlsx`
- Clean one-shot variant only when visual/screenshot/design parity rules are intentionally excluded.

## Production status

This workbook does not prove production readiness. Production remains locked until external live receipts exist.
